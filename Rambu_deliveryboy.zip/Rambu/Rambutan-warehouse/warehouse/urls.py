from django.urls import path,include
from .forms import CustomPasswordResetForm
from .import views
from django.contrib import admin
from django.contrib.auth import views as auth_views
from .views import  CustomPasswordResetConfirmView, CustomPasswordResetView, add_to_wishlist, remove_from_wishlist, update_billing_details
from .views import order_history
from .views import verify_otp, enter_email,register
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='home'),  # Root URL
    path('index/', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('verify-otp/', views.verify_otp, name='verify_otp'),
    path('enter-email/', enter_email, name='enter_email'),
    path('register/', register, name='register'),
    path('login/',views.login_view,name='login'),
    path('farmer_dashboard/',views.farmer_dashboard,name='farmer_dashboard'),
    path('post_rambutan/',views.post_rambutan,name='post_rambutan'),
    path('view_posts/',views.view_posts,name='view_posts'),
    path('customer_dashboard/',views.customer_dashboard, name='customer_dashboard'),
    path('farmer-details/', views.farmer_details, name='farmer_details'),
    path('profile/', views.profile_view, name='profile_view'),
    path('products/', views.products_browse, name='products_browse'),
    path('logout/', views.logout_view, name='logout'),
    path('tree/',views.create_tree_variety),
    path('contact/',views.contact,name='contact'),
    path('profile_view/',views.profile_view,name='profile_view'),
    path('productsingle/',views.product_single,name='product_single'),
    path('blog/',views.blog,name='blog'),
    path('wishlist/add/<int:id>/', add_to_wishlist, name='add_to_wishlist'),
    path('wishlist/remove/<int:id>/',remove_from_wishlist, name='remove_from_wishlist'),
    path('wishlist/', views.wishlist, name='wishlist'), 
    path('view_posts/update_post/<int:id>', views.update_post, name='update_post'),
    path('post/<int:id>/update-quantity/', views.update_quantity, name='update_quantity'),
    path('post/<int:id>/delete/confirm/', views.delete_post_confirmation, name='delete_post_confirmation'),
    path('post/<int:id>/delete/', views.delete_post, name='delete_post'),
    path('cart/', views.cart, name='cart'),
    path('cart/add/<int:rambutan_post_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/remove/<int:cart_item_id>/', views.remove_cart_item, name='remove_cart_item'),
    path('cart/update/<int:cart_item_id>/', views.update_cart_item_quantity, name='update_cart_item_quantity'),
    path('place_order',views.place_order,name='place_order'),
    path('billing/', views.billing_view, name='billing_view'),
    path('order/<int:order_number>/', views.order_detail, name='order_detail'),
    path('order_history/', order_history, name='order_history'),
    path('farmer/orders/', views.farmer_orders, name='farmer_orders'),
    path('notifications/',views.order_notifications, name='order_notifications'),
    path('billing-details/update/<int:pk>/', update_billing_details, name='update_billing_details'),
    path('dashboard/admin/', views.admin_dashboard, name='admin_dashboard'),
    path('farmers/', views.manage_farmers, name='manage_farmers'),
    path('farmer/edit/<int:farmer_id>/', views.edit_farmer, name='edit_farmer'),
    path('farmer/delete/<int:farmer_id>/', views.delete_farmer, name='delete_farmer'),
    path('rambutan/', views.manage_rambutan_posts, name='manage_rambutan_posts'),
    path('rambutan/edit/<int:post_id>/', views.edit_rambutan_post, name='edit_rambutan_post'),
    path('rambutan/delete/<int:post_id>/', views.delete_rambutan_post, name='delete_rambutan_post'),
    path('orders/', views.view_orders, name='view_orders'),
    path('edit-farmer-profile/', views.edit_farmer_profile, name='edit_farmer_profile'),
    path('edit-profile/', views.edit_customer_profile, name='edit_customer_profile'),
    path('cancel_order/<str:order_number>/', views.cancel_order, name='cancel_order'),
    path('razorpay-payment/<int:order_number>/', views.razorpay_payment_view, name='razorpay_payment_view'),
    path('razorpay-payment-complete/', views.razorpay_payment_complete, name='razorpay_payment_complete'),
    path('manage_customers/', views.manage_customers, name='manage_customers'),
    path('customer/<int:user_id>/edit/', views.edit_customer, name='edit_customer'),    
    path('delete_customer/<int:customer_id>/', views.delete_customer, name='delete_customer'),
    path('manage_users/', views.manage_users, name='manage_users'),
    path('edit_user/<int:user_id>/', views.edit_user, name='edit_user'),
    path('delete_user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('toggle_user_availability/<int:user_id>/', views.toggle_user_availability, name='toggle_user_availability'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('orders/<int:order_number>/', views.view_orders, name='view_orders'),
    path('view-order-product/<str:order_number>/', views.admin_order, name='admin_order'),
    path('deliveryboy_login/', views.deliveryboy_login, name='deliveryboy_login'),
    path('deliveryboy_email/', views.deliveryboy_email, name='deliveryboy_email'),
    path('deliveryboy_verify_otp/', views.deliveryboy_verify_otp, name='deliveryboy_verify_otp'),
    path('deliveryboy_register/', views.deliveryboy_register, name='deliveryboy_register'),
    path('deliveryboy_dashboard/', views.deliveryboy_dashboard, name='deliveryboy_dashboard'),
    path('chat/', views.chat_with_bot, name='chat_with_bot'),
    path('chat-interface/', views.chatbot_page, name='chatbot_page'),

    


    path('password-reset/', 
         auth_views.PasswordResetView.as_view(
             template_name='password_reset_form.html',
             form_class=CustomPasswordResetForm
         ), 
         name='password_reset'),
    path('password-reset/done/', 
         auth_views.PasswordResetDoneView.as_view(template_name='password_reset_done.html'), 
         name='password_reset_done'),
    path('reset/<uidb64>/<token>/', 
         auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html'), 
         name='password_reset_confirm'),
    path('reset/done/', 
         auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), 
         name='password_reset_complete'),
    path('approve-delivery-boy/<int:user_id>/', views.approve_delivery_boy, name='approve_delivery_boy'),
    path('reject-delivery-boy/<int:user_id>/', views.reject_delivery_boy, name='reject_delivery_boy'),
    path('manage-deliveries/', views.manage_deliveries, name='manage_deliveries'),
    path('assign-delivery-boy/<int:order_number>/', views.assign_delivery_boy, name='assign_delivery_boy'),
    path('unassign-delivery-boy/<int:order_number>/', views.unassign_delivery_boy, name='unassign_delivery_boy'),
]





